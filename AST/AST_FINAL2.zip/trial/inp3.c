#include<stdio.h>
int main()    
{    
	int a = 10, b = 20;      
	float c = 12.8, d = 76.9899;
	int e = 67, f = 45;
	e = b + e*f;
	int i = 0, j, k;

	while(i < 5) {
		i = i + 1;
		for(j=0; j<5; j++) {
			k = k + 1;
		}
	}

	printf("hello", a);
	scanf("%d", &b);
	a=a+b;  //a=30 (10+20)    
	b=a-b; //b=10 (30-20)    
	a=a-b;//a=20 (30-10)    
}
