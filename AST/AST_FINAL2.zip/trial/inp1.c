#include<stdio.h>
int main()
{
	int a = 6;
	int b;
	if(a==2)
	{
		printf("hello");
		printf("hello %d %d", a, b, c, d);
        	scanf("%d", &b);
        	scanf("%d%d", &b, &a);
		int y=5;
	}
}
