#include<stdio.h>
int main()
{
	int a;
	int b = 10.4;
	if(a>7)
	{
		printf("ERROR");
	}
	int e
	int f = 5
	int g;
}
