#include<stdio.h>
int main() {
	int a = 10;
	float b = 12.0;
	int d = 12;
	int j = 0;

	if (d >= a) {
		j++;
	}

	else if (a < 10) {
		while(j--)
			a = 23*d;
	}
}
