#include<stdio.h>
int main()
{
	int a = 6;
	int b;
	if(a==2)
	{
		int y=5;
	}
}
