int main()
{
	char x = 'a';
	char b = 's';
	int a[5];
	int l = 6 + 2;
	int i;
	for(i = 0;i<10;i++)
	{
		printf("hello");
			
	}
}
